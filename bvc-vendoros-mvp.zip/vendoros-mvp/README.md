# BVC VendorOS MVP v0.1

A mobile-first, dependency-free prototype for food trucks, trailers, and market vendors.

## Run locally
Open `index.html` in a browser, or run `python3 -m http.server 8000` in this directory and open `http://localhost:8000`.

## Publish to GitHub Pages (phone-friendly)
1. Create a new public GitHub repository, e.g. `bvc-vendoros-demo`.
2. Upload `index.html` at the repository root.
3. Go to **Settings → Pages → Build and deployment** and select **Deploy from a branch**, `main`, `/ (root)`.
4. Open the published URL shown by GitHub Pages on your iPhone and optionally choose Safari → Share → Add to Home Screen.

## Features
- Vendor profile and chapter selection
- Event opportunity pipeline with status, date, location, fees
- Event profit calculator with revenue, cost of goods, labor, travel and fees
- Rule-based advisor demo
- Marketing post draft generator and copy
- Mobile navigation and dashboard
- Local browser persistence (localStorage)

## Important limitations
This is a **working offline demo**, not a hosted SaaS or connected autonomous AI agent. No user authentication, real AI inference, external event discovery, payments, multi-user storage, or secure backend. Data is stored only in the current browser and can be cleared. Do not enter sensitive business information.

## Production architecture recommendation
- Frontend: Next.js / React with responsive PWA support
- API: Next.js route handlers or dedicated TypeScript backend
- Identity/database: Supabase Auth + PostgreSQL with row-level security, organization/tenant boundaries
- Core entities: users, vendor_businesses, memberships, chapters, opportunities, applications, bookings, events, products, cost_models, marketing_drafts, ai_runs, approvals, audit_events
- AI: model calls only from server, tool-scoped function calling, retrieval from business records, output validation, rate limits, token budgets, prompt injection controls
- Opportunities: source adapters, provenance and freshness metadata, deduplication, relevance scoring; do not claim verified opportunities without evidence
- Automation: job queue/cron for weekly summaries, approval gates for external actions, idempotent jobs, monitoring and retries
- Integrations: calendar and email OAuth with least privilege; explicit approvals for outbound communication and applications
- Billing: Stripe subscriptions, webhook verification, entitlement checks
- Security: secrets on server, encryption in transit, audit logs, backup/restore, data export/delete, privacy policy, tenant isolation tests
- Operations: error monitoring, analytics, CI, automated tests, staged deployments

## Suggested build sequence
1. Deploy static MVP and gather usability feedback.
2. Implement auth, multi-tenant database, persistent profiles and events.
3. Add live server-side AI advisor with per-vendor context and usage limits.
4. Add sourced opportunity discovery, matching and notifications.
5. Add approval-based external actions, billing and chapter administration.
