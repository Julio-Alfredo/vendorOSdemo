# VendorOS technical architecture

## Product boundaries
Vendor-facing app and BVC administration are separate authorization surfaces. BVC admins must not have unrestricted access to vendor financials. Vendors own their data; chapter managers receive only explicitly authorized membership information.

## Core components
- Web/PWA client (Next.js + TypeScript): responsive dashboard, profile, opportunity CRM, event P&L, marketing studio, AI advisor.
- Auth + tenancy (Supabase Auth): users, organizations, role-based membership, RLS on all tenant tables.
- PostgreSQL: relational records and audit events; optional pgvector for vendor-specific knowledge retrieval.
- API services: authenticated CRUD, finance calculation, opportunities search, AI orchestration, approvals, billing entitlements.
- AI orchestration: model API behind backend; strict tool allowlist; retrieval filtered by vendor_id; provenance; guardrails; budget limits; no arbitrary network access.
- Worker/scheduler: import public opportunity feeds, deduplicate, evaluate matching, generate weekly briefings, send opted-in alerts.
- Stripe: subscriptions, webhooks, plan entitlements; no raw payment card handling.
- External connectors: email/calendar with explicit consent and per-action confirmation for outreach/application submission.

## Data model (first production migration)
users(id, auth_id, created_at)
vendors(id, name, type, base_city, state, travel_radius_miles, specialty, owner_user_id)
vendor_members(id, vendor_id, user_id, role)
chapters(id, name, region)
chapter_memberships(id, chapter_id, vendor_id, status)
opportunities(id, title, organizer, venue, city, state, starts_at, deadline_at, fee, source_url, source_checked_at, verification_status)
vendor_opportunities(id, vendor_id, opportunity_id, status, notes)
event_estimates(id, vendor_id, opportunity_id, sales, cogs, labor, travel, other, fee, projected_profit)
marketing_drafts(id, vendor_id, content, channel, status)
ai_runs(id, vendor_id, user_id, purpose, tokens_used, cost_estimate, created_at)
approval_requests(id, vendor_id, action_type, payload, status, approved_by, approved_at)
audit_events(id, vendor_id, actor_id, event_type, metadata, created_at)
subscriptions(id, vendor_id, stripe_customer_id, stripe_subscription_id, status, plan)

## API surface
GET/PATCH /api/vendor
GET/POST /api/events
GET/POST /api/opportunities
POST /api/finance/estimate
POST /api/ai/advice
POST /api/marketing/draft
GET/POST /api/approvals
POST /api/webhooks/stripe
GET /api/admin/chapters (BVC admin only)

## Agent capabilities and controls
Research agent: searches allowlisted public sources and records citations, timestamps, and confidence. Cannot claim availability or submit applications without confirmation.
Financial agent: deterministic calculations, clear assumptions, separate from model-generated explanations.
Marketing agent: generates drafts; publishes only after explicit user approval.
Operations agent: reminders and checklists, no irreversible actions.
Weekly briefing: opt-in scheduled job with deduplication, cancellation, and audit trail.

## Definition of done for public beta
Account creation, isolation tests across vendors, data export/delete, source attribution, functional mobile UX, verified payment entitlement behavior, end-to-end tests, monitoring, and accessible support/privacy pages.
